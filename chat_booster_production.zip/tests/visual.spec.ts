import { test, expect } from '@playwright/test';
test('basic page visual', async ({ page })=>{
  await page.goto('http://localhost:3000');
  const img = await page.screenshot();
  expect(img.length).toBeGreaterThan(0);
});
