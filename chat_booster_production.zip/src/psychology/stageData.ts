const stageData = {
  ambiguous: {
    name: '曖昧期',
    weight: 0.30,
    styles: [{ method: '情感揭露法', psychological: ['脆弱性'], template: '看到「{{context}}」…我承認我很在意。' }]
  },
  passionate: {
    name: '熱戀期',
    weight: 0.28,
    styles: [{ method: '枕邊對話法', psychological: ['親密'], template: '寶貝你說「{{context}}」，我好想聽你更多。' }]
  },
  pursuit: {
    name: '追求期',
    weight: 0.25,
    styles: [{ method: '故事分享法', psychological: ['連結'], template: '你說「{{context}}」，讓我想到一個小故事...' }]
  },
  married: {
    name: '長期/婚後',
    weight: 0.17,
    styles: [{ method: '日常儀式', psychological: ['陪伴'], template: '親愛的，聽到「{{context}}」我覺得很幸福。' }]
  }
};
export default stageData;
