'use client';
import React, { useState } from 'react';
import useReplyEngine from '../hooks/useReplyEngine';
export default function ReplyGenerator(){
  const [input,setInput]=useState('');
  const [replies,setReplies]=useState<any[]>([]);
  const { generate, isLoading } = useReplyEngine();
  async function onGen(){ if(!input.trim()) return; const res = await generate(input,['ambiguous','passionate']); setReplies(res); }
  return (<div className="p-6 max-w-2xl mx-auto">
    <textarea value={input} onChange={e=>setInput(e.target.value)} className="w-full p-3 rounded" rows={4} placeholder="輸入對方訊息..." />
    <div className="flex gap-2 mt-3">
      <button onClick={onGen} className="px-4 py-2 bg-rose-500 text-white rounded">{isLoading?'...':'生成'}</button>
    </div>
    <div className="mt-4 space-y-3">
      {replies.map((r,i)=>(<div key={i} className="p-3 bg-white rounded shadow"><div className="text-sm">{r.text}</div><div className="text-xs text-gray-500">{r.stageId} • {r.score.toFixed(2)}</div></div>))}
    </div>
  </div>);
}
