import { useState } from 'react';
import stageData from '../psychology/stageData';
import weights from '../psychology/weights.json';
export type Reply = { text:string, stageId:string, score:number };
export default function useReplyEngine(){ 
  const [isLoading,setIsLoading]=useState(false);
  async function generate(input:string, stages:string[]){ setIsLoading(true);
    // simplified generation logic
    const replies: Reply[] = [];
    stages.forEach(sid=>{
      const st = (stageData as any)[sid];
      (st.styles||[]).forEach((style:any)=>{
        const text = style.template.replace('{{context}}', input);
        const score = (weights[sid]||st.weight||0.2)*(1+Math.random()*0.1);
        replies.push({ text, stageId:sid, score });
      });
    });
    replies.sort((a,b)=>b.score-a.score);
    setIsLoading(false);
    return replies;
  }
  return { generate, isLoading };
}
