import { useCallback } from 'react';
type StorageDriver = { get: (k:string)=>Promise<any>, set:(k:string,v:any)=>Promise<void> };
export function createWindowDriver(): StorageDriver {
  const driver: StorageDriver = {
    async get(k){ const v = (window as any).storage?.get ? await (window as any).storage.get(k) : null; return v; },
    async set(k,v){ if((window as any).storage?.set) await (window as any).storage.set(k,v); }
  };
  return driver;
}
export default function useStorage(driver?: StorageDriver) {
  const d = driver ?? createWindowDriver();
  const load = useCallback(async (key:string)=>{ try{ const r = await d.get(key); return r; }catch(e){return null} },[d]);
  const save = useCallback(async (key:string,value:any)=>{ try{ await d.set(key,value); }catch(e){} },[d]);
  return { load, save };
}
