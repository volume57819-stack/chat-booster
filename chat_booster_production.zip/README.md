# chat-booster (production scaffold)

This is a production-ready scaffold for the chat-booster project.
- Next.js (App Router)
- TypeScript
- Tailwind
- Jest & Playwright in CI
- GitHub Actions for daily/monthly analysis & auto-optimize
- Vercel deploy workflow

See .github/workflows for CI definitions.
