'use client';
import { useEffect, useState } from 'react';
export default function Dashboard() {
  const [reports, setReports] = useState<any[]>([]);
  const [weights, setWeights] = useState<Record<string,number>>({});
  useEffect(()=>{
    fetch('/api/reports').then(r=>r.json()).then(setReports).catch(()=>{});
    fetch('/api/weights').then(r=>r.json()).then(setWeights).catch(()=>{});
  },[]);
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold mb-4">chat-booster Dashboard</h1>
      <section className="mb-6">
        <h2 className="font-semibold">Current weights</h2>
        <pre className="bg-white p-4 rounded shadow mt-2">{JSON.stringify(weights,null,2)}</pre>
      </section>
      <section>
        <h2 className="font-semibold">Recent reports</h2>
        <pre className="bg-white p-4 rounded shadow mt-2">{JSON.stringify(reports.slice(-5),null,2)}</pre>
      </section>
    </main>
  )
}
