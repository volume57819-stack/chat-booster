import ReplyGenerator from '../src/components/ReplyGenerator';
export default function Page(){ return (<main><ReplyGenerator/></main>); }
