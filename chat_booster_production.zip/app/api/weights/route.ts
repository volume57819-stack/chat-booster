import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
export async function GET() {
  const p = path.join(process.cwd(),'src','psychology','weights.json');
  if (!fs.existsSync(p)) return NextResponse.json({});
  const content = JSON.parse(fs.readFileSync(p,'utf-8'));
  return NextResponse.json(content);
}
