import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
export async function GET() {
  const dir = path.join(process.cwd(),'analysis');
  if (!fs.existsSync(dir)) return NextResponse.json([]);
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
  const reports = files.map(f => JSON.parse(fs.readFileSync(path.join(dir,f),'utf-8')));
  return NextResponse.json(reports);
}
