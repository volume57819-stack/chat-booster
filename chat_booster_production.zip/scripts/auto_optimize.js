// auto_optimize.js
const fs=require('fs'),path=require('path'),{execSync}=require('child_process');
const dir = (process.argv.find(a=>a.startsWith('--analysisDir='))||'--analysisDir=analysis').split('=')[1];
if(!fs.existsSync(dir)){ console.log('no reports'); process.exit(0); }
const files = fs.readdirSync(dir).filter(f=>f.endsWith('.json')).map(f=>JSON.parse(fs.readFileSync(path.join(dir,f),'utf-8')));
const agg={}; files.forEach(r=>Object.entries(r.signals||{}).forEach(([k,v])=>agg[k]=(agg[k]||0)+v));
const suggestions = {}; Object.keys(agg).forEach((k)=> suggestions[k]=Math.min(0.45,Math.max(0.05,agg[k]/(files.length*10))));
const weightsPath = path.join(process.cwd(),'src','psychology','weights.json'); let weights={};
if(fs.existsSync(weightsPath)) weights = JSON.parse(fs.readFileSync(weightsPath,'utf-8'));
const newWeights = Object.assign({}, weights, suggestions);
fs.writeFileSync(weightsPath, JSON.stringify(newWeights,null,2));
const branch = `auto-opt-${new Date().toISOString().replace(/[:.]/g,'-')}`;
execSync('git config user.email "actions@users.noreply.github.com"'); execSync('git config user.name "auto-opt-bot"');
execSync(`git checkout -b ${branch}`); execSync(`git add ${weightsPath}`); execSync(`git commit -m "auto-opt: update weights"`); execSync(`git push origin ${branch}`);
console.log('pushed', branch);
