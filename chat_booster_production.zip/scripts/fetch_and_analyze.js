// fetch_and_analyze.js
const fs = require('fs'), path = require('path');
const outDir = (process.argv.find(a=>a.startsWith('--outDir='))||'--outDir=analysis').split('=')[1] || 'analysis';
if(!fs.existsSync(outDir)) fs.mkdirSync(outDir,{recursive:true});
const signals = { google: Math.random()*10, reddit: Math.random()*10, x: Math.random()*10 };
const out = { date: new Date().toISOString(), signals, meta:{note:'auto'} };
const file = path.join(outDir, `report-${new Date().toISOString().slice(0,10)}.json`);
fs.writeFileSync(file, JSON.stringify(out,null,2));
console.log('wrote', file);
